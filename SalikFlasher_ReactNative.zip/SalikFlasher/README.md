# Salik GX6605S Flasher — تطبيق أندرويد

تطبيق React Native لفلاشة رسيفر GX6605S عبر USB OTG مباشرة من الهاتف.

## المتطلبات

- هاتف أندرويد يدعم **USB OTG** (أندرويد 5.0+)
- **كابل OTG** (USB Type-C أو Micro-USB حسب هاتفك) → USB Type-A
- رسيفر في **وضع Flash** (عادةً بضغط زر معين عند التشغيل)
- Node.js 18+ و React Native CLI

## التثبيت

```bash
npm install
npx react-native run-android
```

## بناء APK للإصدار

```bash
cd android
./gradlew assembleRelease
# الناتج في: android/app/build/outputs/apk/release/app-release.apk
```

## هيكل المشروع

```
SalikFlasher/
├── App.js                          ← التنقل الرئيسي
├── src/
│   ├── screens/
│   │   ├── HomeScreen.js           ← الاتصال بالجهاز
│   │   ├── FlashScreen.js          ← عملية الفلاش
│   │   ├── ConfigScreen.js         ← تعديل config.ini
│   │   └── TerminalScreen.js       ← طرفية Serial
│   └── utils/
│       ├── UsbSerial.js            ← بروتوكول GX Downloader
│       └── ConfigParser.js         ← تحليل config.ini
└── android/
    └── app/src/main/
        ├── AndroidManifest.xml     ← صلاحيات USB
        └── res/xml/
            └── usb_device_filter.xml ← VID/PID الأجهزة
```

## بروتوكول GX6605S

| الأمر | الكود | الوصف |
|-------|-------|-------|
| Handshake | 0x55 | الاتصال الأولي |
| ACK | 0xAA | استجابة الرسيفر |
| Get Info | 0x01 | معلومات الشريحة |
| Erase | 0x02 | مسح الذاكرة |
| Write | 0x03 | كتابة chunk (512 bytes) |
| Verify | 0x05 | التحقق بـ CRC32 |
| Reboot | 0x06 | إعادة التشغيل |

**Baud Rate:** 115200 — **Data:** 8N1

## شاشات التطبيق

1. **الرئيسية** — كشف الأجهزة USB وإدارة الاتصال
2. **فلاش الفيرموير** — اختيار الملف، مسح، كتابة، تحقق بشريط تقدم
3. **إعدادات Flash** — تحميل وتعديل وحفظ config.ini مع خريطة مرئية
4. **الطرفية** — إرسال أوامر HEX/ASCII مباشرة مع سجل الردود

## ملاحظات مهمة

- بعض رسيفرات GX6605S تحتاج ضغط زر خاص عند التشغيل للدخول في وضع Flash
- إذا لم يُعرَّف الجهاز تلقائياً، أضف VID/PID يدوياً في `usb_device_filter.xml`
- تأكد من تفعيل **USB Debugging** أو **USB Host Mode** في إعدادات المطور
