// App.js — نقطة دخول التطبيق
import React from 'react';
import { StatusBar } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import HomeScreen     from './src/screens/HomeScreen';
import FlashScreen    from './src/screens/FlashScreen';
import ConfigScreen   from './src/screens/ConfigScreen';
import TerminalScreen from './src/screens/TerminalScreen';

const Tab = createBottomTabNavigator();

const TAB_ICONS = { الرئيسية:'🏠', 'فلاش الفيرموير':'⚡', 'إعدادات Flash':'⚙️', الطرفية:'🖥️' };

export default function App() {
  return (
    <SafeAreaProvider>
      <StatusBar barStyle="light-content" backgroundColor="#0f1117"/>
      <NavigationContainer>
        <Tab.Navigator
          screenOptions={({ route }) => ({
            tabBarIcon: () => null,
            tabBarLabel: route.name,
            tabBarActiveTintColor: '#4f8ef7',
            tabBarInactiveTintColor: '#8892a4',
            tabBarStyle: { backgroundColor: '#1a1d27', borderTopColor: '#2e3350', height: 58 },
            tabBarLabelStyle: { fontSize: 12, marginBottom: 6 },
            headerStyle: { backgroundColor: '#1a1d27', borderBottomColor: '#2e3350', borderBottomWidth: 1 },
            headerTintColor: '#e2e8f0',
            headerTitleStyle: { fontWeight: '700' },
            headerRight: () => null,
          })}
        >
          <Tab.Screen name="الرئيسية"       component={HomeScreen}     />
          <Tab.Screen name="فلاش الفيرموير" component={FlashScreen}    />
          <Tab.Screen name="إعدادات Flash"  component={ConfigScreen}   />
          <Tab.Screen name="الطرفية"        component={TerminalScreen} />
        </Tab.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  );
}
