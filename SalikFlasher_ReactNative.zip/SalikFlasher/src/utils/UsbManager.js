import {UsbSerialport} from 'react-native-usb-serialport-for-android';

// ── بروتوكول GX6605S UART ──
// Baud rate افتراضي: 115200
// تنسيق: 8N1 (8 data bits, No parity, 1 stop bit)

const BAUD_RATE = 115200;
const CMD_TIMEOUT = 5000;

// أوامر بروتوكول GX Downloader
const GX_CMD = {
  HANDSHAKE:    0x55,
  ACK:          0xAA,
  GET_VERSION:  0x01,
  ERASE:        0x02,
  WRITE:        0x03,
  READ:         0x04,
  VERIFY:       0x05,
  REBOOT:       0x06,
  GET_CHIP_ID:  0x07,
};

const GX_HEADER = [0x47, 0x58];  // "GX"
const CHUNK_SIZE = 4096;          // 4KB per write packet

class UsbManager {
  constructor() {
    this.device   = null;
    this.port     = null;
    this.deviceId = null;
    this.listeners = [];
    this._rxBuffer = [];
  }

  // ── جلب الأجهزة المتصلة ──
  async listDevices() {
    try {
      const devices = await UsbSerialport.list();
      return devices;
    } catch (e) {
      throw new Error('فشل البحث عن أجهزة USB: ' + e.message);
    }
  }

  // ── الاتصال بالرسيفر ──
  async connect(deviceId) {
    try {
      // طلب صلاحية USB من أندرويد
      const granted = await UsbSerialport.tryRequestPermission(deviceId);
      if (!granted) throw new Error('رُفض إذن USB');

      this.port = await UsbSerialport.open(deviceId, {
        baudRate:  BAUD_RATE,
        dataBits:  8,
        parity:    0,   // NONE
        stopBits:  1,
        driver:    'CdcAcmSerialDriver',
      });

      this.deviceId = deviceId;

      // مستمع البيانات الواردة
      this.port.addListener('data', data => {
        this._rxBuffer.push(...data);
        this.listeners.forEach(fn => fn('data', data));
      });

      this.port.addListener('error', err => {
        this.listeners.forEach(fn => fn('error', err));
      });

      return true;
    } catch (e) {
      throw new Error('فشل الاتصال: ' + e.message);
    }
  }

  // ── قطع الاتصال ──
  async disconnect() {
    try {
      if (this.port) {
        await this.port.close();
        this.port = null;
        this.deviceId = null;
        this._rxBuffer = [];
      }
    } catch (_) {}
  }

  isConnected() {
    return this.port !== null;
  }

  addListener(fn) {
    this.listeners.push(fn);
    return () => { this.listeners = this.listeners.filter(l => l !== fn); };
  }

  // ── إرسال بيانات خام ──
  async write(bytes) {
    if (!this.port) throw new Error('غير متصل');
    return this.port.send(bytes);
  }

  // ── قراءة مع timeout ──
  async readBytes(count, timeout = CMD_TIMEOUT) {
    return new Promise((resolve, reject) => {
      const deadline = setTimeout(() => reject(new Error('انتهت مهلة القراءة')), timeout);
      const check = setInterval(() => {
        if (this._rxBuffer.length >= count) {
          clearInterval(check);
          clearTimeout(deadline);
          resolve(this._rxBuffer.splice(0, count));
        }
      }, 20);
    });
  }

  clearRx() { this._rxBuffer = []; }

  // ═══════════════════════════════════════
  // بروتوكول GX Downloader
  // ═══════════════════════════════════════

  // بناء حزمة الأمر
  _buildPacket(cmd, payload = []) {
    const len = payload.length;
    const packet = [
      ...GX_HEADER,
      cmd,
      (len >> 8) & 0xFF,
      len & 0xFF,
      ...payload,
    ];
    // checksum بسيط (XOR)
    const cksum = packet.slice(2).reduce((a, b) => a ^ b, 0);
    packet.push(cksum);
    return new Uint8Array(packet);
  }

  // مصافحة أولية مع الرسيفر
  async handshake() {
    this.clearRx();
    await this.write(new Uint8Array([GX_CMD.HANDSHAKE]));
    const resp = await this.readBytes(1, 3000);
    if (resp[0] !== GX_CMD.ACK) throw new Error('الرسيفر لم يستجب — تأكد من وضع Download Mode');
    return true;
  }

  // جلب معرف الشريحة
  async getChipId() {
    const pkt = this._buildPacket(GX_CMD.GET_CHIP_ID);
    this.clearRx();
    await this.write(pkt);
    const resp = await this.readBytes(8);
    // 4 bytes chip ID بعد الـ ACK
    const chipId = (resp[2] << 24) | (resp[3] << 16) | (resp[4] << 8) | resp[5];
    return '0x' + chipId.toString(16).padStart(8, '0').toUpperCase();
  }

  // محو قسم من الذاكرة
  async eraseSegment(startAddr, size) {
    const payload = [
      (startAddr >> 24) & 0xFF,
      (startAddr >> 16) & 0xFF,
      (startAddr >>  8) & 0xFF,
       startAddr        & 0xFF,
      (size >> 24) & 0xFF,
      (size >> 16) & 0xFF,
      (size >>  8) & 0xFF,
       size        & 0xFF,
    ];
    const pkt = this._buildPacket(GX_CMD.ERASE, payload);
    this.clearRx();
    await this.write(pkt);
    const resp = await this.readBytes(3, 15000);  // المحو يأخذ وقتاً
    if (resp[0] !== GX_CMD.ACK) throw new Error('فشل المحو');
    return true;
  }

  // كتابة ملف الفيرموير chunk بـ chunk
  async flashFirmware(fileData, startAddr, onProgress) {
    const totalSize = fileData.length;
    let offset = 0;
    let packet = 0;

    while (offset < totalSize) {
      const chunk = fileData.slice(offset, offset + CHUNK_SIZE);
      const addr  = startAddr + offset;

      const addrBytes = [
        (addr >> 24) & 0xFF,
        (addr >> 16) & 0xFF,
        (addr >>  8) & 0xFF,
         addr        & 0xFF,
      ];
      const lenBytes = [
        (chunk.length >> 8) & 0xFF,
         chunk.length       & 0xFF,
      ];

      const payload = [...addrBytes, ...lenBytes, ...Array.from(chunk)];
      const pkt = this._buildPacket(GX_CMD.WRITE, payload);

      this.clearRx();
      await this.write(pkt);
      const resp = await this.readBytes(3, 10000);
      if (resp[0] !== GX_CMD.ACK) throw new Error(`فشل الكتابة عند العنوان 0x${addr.toString(16).toUpperCase()}`);

      offset += chunk.length;
      packet++;

      if (onProgress) {
        onProgress({
          bytesWritten: offset,
          totalBytes:   totalSize,
          percent:      Math.round((offset / totalSize) * 100),
          currentAddr:  '0x' + addr.toString(16).padStart(8, '0').toUpperCase(),
          packet,
        });
      }

      // استراحة قصيرة لمنع overflow
      await new Promise(r => setTimeout(r, 5));
    }
    return true;
  }

  // التحقق من الكتابة بعد الانتهاء
  async verifyFlash(startAddr, size, expectedCrc) {
    const payload = [
      (startAddr >> 24) & 0xFF,
      (startAddr >> 16) & 0xFF,
      (startAddr >>  8) & 0xFF,
       startAddr        & 0xFF,
      (size >> 24) & 0xFF,
      (size >> 16) & 0xFF,
      (size >>  8) & 0xFF,
       size        & 0xFF,
    ];
    const pkt = this._buildPacket(GX_CMD.VERIFY, payload);
    this.clearRx();
    await this.write(pkt);
    const resp = await this.readBytes(6, 20000);
    if (resp[0] !== GX_CMD.ACK) throw new Error('فشل التحقق');
    const crc = (resp[2] << 24) | (resp[3] << 16) | (resp[4] << 8) | resp[5];
    return crc === expectedCrc;
  }

  // إعادة تشغيل الرسيفر
  async reboot() {
    const pkt = this._buildPacket(GX_CMD.REBOOT);
    await this.write(pkt);
  }
}

export default new UsbManager();
export {CHUNK_SIZE, GX_CMD};
