// src/utils/ConfigParser.js
export function parseConfig(text) {
  const lines = text.replace(/\r/g, '').split('\n');
  const sections = {};
  let current = null;
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith(';')) continue;
    const sectionMatch = trimmed.match(/^\[(.+)\]$/);
    if (sectionMatch) { current = sectionMatch[1]; sections[current] = {}; continue; }
    const kvMatch = trimmed.match(/^(.+?)\s*=\s*(.+)$/);
    if (kvMatch && current) sections[current][kvMatch[1].trim()] = kvMatch[2].trim();
  }
  return buildSegments(sections);
}
function buildSegments(sections) {
  const main = sections['Main'] || {};
  const segCount = parseInt(main['SegNumber'] || '0', 10);
  const segments = [];
  for (let i = 0; i < segCount; i++) {
    const name = main['Seg' + i];
    if (!name || !sections[name]) continue;
    const sec = sections[name];
    const startHex = sec['StartAddr'] || '0x0';
    const sizeHex = (sec['SegSize'] || sec['SegSize   '] || '0x0').trim();
    const startInt = parseInt(startHex, 16);
    const sizeInt = parseInt(sizeHex, 16);
    segments.push({ index: i, name, startAddr: startHex, size: sizeHex, startInt, sizeInt, endInt: startInt + sizeInt });
  }
  return segments;
}
export function serializeConfig(segments) {
  let out = '[Main]\r\n';
  out += 'SegNumber=' + segments.length + '\r\n';
  segments.forEach((s, i) => { out += 'Seg' + i + '=' + s.name + '\r\n'; });
  for (const seg of segments) {
    out += '\r\n[' + seg.name + ']\r\n';
    out += 'StartAddr=' + seg.startAddr + '\r\n';
    out += 'SegSize   =' + seg.size + '\r\n';
  }
  return out;
}
export function validateSegments(segments) {
  const errors = [];
  for (const seg of segments) {
    if (seg.sizeInt <= 0) errors.push(seg.name + ': حجم غير صالح');
    if (seg.startInt < 0) errors.push(seg.name + ': عنوان سالب');
    if (seg.endInt > 0x800000) errors.push(seg.name + ': يتجاوز 8MB');
  }
  return errors;
}
