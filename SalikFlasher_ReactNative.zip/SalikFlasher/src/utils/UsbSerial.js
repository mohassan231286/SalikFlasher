// src/utils/UsbSerial.js
// التواصل مع رسيفر GX6605S عبر USB OTG Serial
// بروتوكول GX Downloader — Baud Rate: 115200, 8N1

import { UsbSerialport } from 'react-native-usb-serialport-for-android';

// ── ثوابت البروتوكول ──────────────────────────────
const BAUD_RATE     = 115200;
const DATA_BITS     = 8;
const STOP_BITS     = 1;
const PARITY        = 0; // None

// أوامر GX Downloader Protocol
const CMD = {
  HANDSHAKE:    0x55,
  ACK:          0xAA,
  GET_INFO:     0x01,
  ERASE:        0x02,
  WRITE:        0x03,
  READ:         0x04,
  VERIFY:       0x05,
  REBOOT:       0x06,
  SET_BAUDRATE: 0x07,
};

// حجم كل chunk عند الكتابة (512 bytes)
const CHUNK_SIZE = 512;

// ── حالة الاتصال ──────────────────────────────────
let _port      = null;
let _connected = false;
let _listeners = [];

// ── دوال مساعدة ──────────────────────────────────

function toHex(n, bytes = 4) {
  return '0x' + n.toString(16).padStart(bytes * 2, '0').toUpperCase();
}

function buildPacket(cmd, data = []) {
  // هيكل الحزمة: [0x55, 0xAA, CMD, LEN_HIGH, LEN_LOW, ...DATA, CHECKSUM]
  const len   = data.length;
  const buf   = [0x55, 0xAA, cmd, (len >> 8) & 0xFF, len & 0xFF, ...data];
  const csum  = buf.reduce((a, b) => (a + b) & 0xFF, 0);
  return Buffer.from([...buf, csum]);
}

function calcChecksum(data) {
  return data.reduce((a, b) => (a + b) & 0xFF, 0);
}

function emitLog(msg, type = 'info') {
  _listeners.forEach(fn => fn({ msg, type, ts: Date.now() }));
}

// ── API رئيسي ──────────────────────────────────

const UsbSerial = {

  // ── قائمة الأجهزة المتصلة ──
  async listDevices() {
    try {
      const devices = await UsbSerialport.list();
      return devices;
    } catch (e) {
      emitLog('فشل الحصول على قائمة الأجهزة: ' + e.message, 'error');
      return [];
    }
  },

  // ── فتح الاتصال ──
  async connect(deviceId) {
    try {
      emitLog('جاري فتح منفذ USB...', 'info');
      _port = await UsbSerialport.open({
        deviceId,
        baudRate:  BAUD_RATE,
        dataBits:  DATA_BITS,
        stopBits:  STOP_BITS,
        parity:    PARITY,
      });
      _connected = true;
      emitLog(`تم الاتصال بالجهاز #${deviceId} — Baud: ${BAUD_RATE}`, 'success');

      // محاولة Handshake مع الرسيفر
      const ok = await UsbSerial.handshake();
      if (!ok) {
        emitLog('تحذير: لم يستجب الرسيفر — تأكد من وضعه في وضع Flash', 'warn');
      }
      return true;
    } catch (e) {
      emitLog('فشل الاتصال: ' + e.message, 'error');
      _connected = false;
      return false;
    }
  },

  // ── قطع الاتصال ──
  async disconnect() {
    if (_port) {
      try {
        await UsbSerialport.close();
      } catch (_) {}
      _port      = null;
      _connected = false;
      emitLog('تم قطع الاتصال', 'info');
    }
  },

  isConnected() {
    return _connected;
  },

  // ── Handshake مع الرسيفر ──
  async handshake() {
    try {
      emitLog('إرسال Handshake...', 'info');
      await UsbSerialport.write(Buffer.from([CMD.HANDSHAKE]).toString('base64'));
      const resp = await this._readTimeout(100);
      if (resp && resp[0] === CMD.ACK) {
        emitLog('الرسيفر يستجيب ✓', 'success');
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  },

  // ── قراءة معلومات الرسيفر ──
  async getDeviceInfo() {
    try {
      emitLog('قراءة معلومات الرسيفر...', 'info');
      const pkt = buildPacket(CMD.GET_INFO);
      await UsbSerialport.write(pkt.toString('base64'));
      const resp = await this._readTimeout(2000);
      if (!resp || resp.length < 16) {
        emitLog('لا توجد استجابة من الرسيفر', 'warn');
        return null;
      }
      return {
        chipId:      toHex((resp[4] << 24) | (resp[5] << 16) | (resp[6] << 8) | resp[7]),
        flashSize:   ((resp[8] << 24) | (resp[9] << 16) | (resp[10] << 8) | resp[11]),
        firmwareVer: `${resp[12]}.${resp[13]}.${resp[14]}`,
        model:       'GX6605S',
      };
    } catch (e) {
      emitLog('خطأ في قراءة المعلومات: ' + e.message, 'error');
      return null;
    }
  },

  // ── مسح منطقة الذاكرة ──
  async eraseFlash(startAddr, size, onProgress) {
    try {
      emitLog(`مسح الذاكرة: ${toHex(startAddr)} حجم ${(size / 1024).toFixed(0)} KB`, 'info');
      const data = [
        (startAddr >> 24) & 0xFF, (startAddr >> 16) & 0xFF,
        (startAddr >> 8)  & 0xFF,  startAddr & 0xFF,
        (size >> 24) & 0xFF, (size >> 16) & 0xFF,
        (size >> 8)  & 0xFF,  size & 0xFF,
      ];
      const pkt = buildPacket(CMD.ERASE, data);
      await UsbSerialport.write(pkt.toString('base64'));

      // انتظار تأكيد المسح (يأخذ وقتاً)
      const resp = await this._readTimeout(30000, onProgress);
      if (!resp || resp[0] !== CMD.ACK) {
        throw new Error('الرسيفر لم يؤكد المسح');
      }
      emitLog('تم مسح الذاكرة ✓', 'success');
      return true;
    } catch (e) {
      emitLog('فشل المسح: ' + e.message, 'error');
      return false;
    }
  },

  // ── كتابة الفيرموير (chunk by chunk) ──
  async writeFlash(startAddr, fileData, onProgress) {
    const totalBytes = fileData.length;
    let offset       = 0;
    let chunkIndex   = 0;
    const totalChunks = Math.ceil(totalBytes / CHUNK_SIZE);

    emitLog(`بدء الكتابة: ${totalBytes.toLocaleString()} bytes — ${totalChunks} chunk`, 'info');

    try {
      while (offset < totalBytes) {
        const chunkData   = fileData.slice(offset, offset + CHUNK_SIZE);
        const curAddr     = startAddr + offset;
        const addrBytes   = [
          (curAddr >> 24) & 0xFF, (curAddr >> 16) & 0xFF,
          (curAddr >> 8)  & 0xFF,  curAddr & 0xFF,
        ];
        const payload = [...addrBytes, ...chunkData];
        const pkt     = buildPacket(CMD.WRITE, payload);

        await UsbSerialport.write(pkt.toString('base64'));
        const resp = await this._readTimeout(5000);

        if (!resp || resp[0] !== CMD.ACK) {
          throw new Error(`فشل chunk ${chunkIndex + 1}/${totalChunks} عند ${toHex(curAddr)}`);
        }

        offset     += chunkData.length;
        chunkIndex += 1;
        const pct   = Math.round((offset / totalBytes) * 100);
        if (onProgress) onProgress(pct, chunkIndex, totalChunks);

        if (chunkIndex % 20 === 0) {
          emitLog(`تقدم الكتابة: ${pct}% — ${toHex(curAddr)}`, 'info');
        }
      }
      emitLog('اكتملت الكتابة ✓', 'success');
      return true;
    } catch (e) {
      emitLog('فشل الكتابة: ' + e.message, 'error');
      return false;
    }
  },

  // ── التحقق من الكتابة (Verify) ──
  async verifyFlash(startAddr, size, expectedCrc) {
    try {
      emitLog('جاري التحقق...', 'info');
      const data = [
        (startAddr >> 24) & 0xFF, (startAddr >> 16) & 0xFF,
        (startAddr >> 8)  & 0xFF,  startAddr & 0xFF,
        (size >> 24) & 0xFF, (size >> 16) & 0xFF,
        (size >> 8)  & 0xFF,  size & 0xFF,
      ];
      const pkt  = buildPacket(CMD.VERIFY, data);
      await UsbSerialport.write(pkt.toString('base64'));
      const resp = await this._readTimeout(10000);
      if (!resp || resp.length < 6) throw new Error('لا توجد استجابة');

      const crc = (resp[4] << 24) | (resp[5] << 16) | (resp[6] << 8) | resp[7];
      const ok  = crc === expectedCrc;
      emitLog(`Verify: CRC=${toHex(crc)} — ${ok ? 'مطابق ✓' : 'غير مطابق ✗'}`, ok ? 'success' : 'error');
      return ok;
    } catch (e) {
      emitLog('فشل التحقق: ' + e.message, 'error');
      return false;
    }
  },

  // ── إعادة تشغيل الرسيفر ──
  async reboot() {
    try {
      const pkt = buildPacket(CMD.REBOOT);
      await UsbSerialport.write(pkt.toString('base64'));
      emitLog('أُرسل أمر إعادة التشغيل ✓', 'success');
      return true;
    } catch (e) {
      emitLog('فشل إرسال أمر الإقلاع: ' + e.message, 'error');
      return false;
    }
  },

  // ── الاستماع لسجل الأحداث ──
  onLog(fn) {
    _listeners.push(fn);
    return () => { _listeners = _listeners.filter(l => l !== fn); };
  },

  // ── قراءة مع Timeout ──
  async _readTimeout(ms, tickFn) {
    return new Promise((resolve) => {
      let buf     = [];
      let timer   = null;
      let tickInt = null;

      const sub = UsbSerialport.onReceived((data) => {
        buf = [...buf, ...Array.from(Buffer.from(data, 'base64'))];
        clearTimeout(timer);
        timer = setTimeout(() => { sub.remove(); if (tickInt) clearInterval(tickInt); resolve(buf); }, 200);
      });

      if (tickFn) tickInt = setInterval(() => tickFn(), 500);

      setTimeout(() => {
        sub.remove();
        if (tickInt) clearInterval(tickInt);
        resolve(buf.length ? buf : null);
      }, ms);
    });
  },
};

export default UsbSerial;
export { CMD, CHUNK_SIZE, buildPacket, calcChecksum, toHex };
