import React, {useState, useEffect, useCallback} from 'react';
import {
  View, Text, TouchableOpacity, FlatList,
  StyleSheet, ActivityIndicator, Alert,
} from 'react-native';
import UsbManager from '../utils/UsbManager';

const COLORS = {
  bg: '#0f1117', bg2: '#1a1d27', bg3: '#22263a',
  border: '#2e3350', text: '#e2e8f0', muted: '#8892a4',
  accent: '#4f8ef7', green: '#22c55e', amber: '#f59e0b', red: '#ef4444',
};

export default function ConnectScreen({onConnected}) {
  const [devices, setDevices]     = useState([]);
  const [scanning, setScanning]   = useState(false);
  const [connecting, setConn]     = useState(null);
  const [connected, setConnected] = useState(false);
  const [chipId, setChipId]       = useState(null);
  const [log, setLog]             = useState([]);

  const addLog = msg => setLog(prev => [`[${new Date().toLocaleTimeString()}] ${msg}`, ...prev.slice(0, 49)]);

  const scanDevices = useCallback(async () => {
    setScanning(true);
    try {
      const list = await UsbManager.listDevices();
      setDevices(list);
      addLog(`وُجد ${list.length} جهاز USB`);
    } catch (e) {
      addLog('خطأ: ' + e.message);
    } finally {
      setScanning(false);
    }
  }, []);

  useEffect(() => { scanDevices(); }, [scanDevices]);

  const connect = async device => {
    setConn(device.deviceId);
    addLog(`جارٍ الاتصال بـ ${device.name || device.deviceId}...`);
    try {
      await UsbManager.connect(device.deviceId);
      addLog('تم الاتصال — جارٍ مصافحة الرسيفر...');
      await UsbManager.handshake();
      addLog('✓ مصافحة ناجحة');
      const id = await UsbManager.getChipId();
      setChipId(id);
      addLog('✓ معرف الشريحة: ' + id);
      setConnected(true);
      if (onConnected) onConnected(device, id);
    } catch (e) {
      addLog('✗ ' + e.message);
      Alert.alert('فشل الاتصال', e.message);
      await UsbManager.disconnect();
    } finally {
      setConn(null);
    }
  };

  const disconnect = async () => {
    await UsbManager.disconnect();
    setConnected(false);
    setChipId(null);
    addLog('قُطع الاتصال');
  };

  if (connected) {
    return (
      <View style={s.container}>
        <View style={s.connectedCard}>
          <View style={s.connDot} />
          <View style={{flex: 1}}>
            <Text style={s.connTitle}>متصل بالرسيفر</Text>
            <Text style={s.connSub}>GX6605S — معرف الشريحة: {chipId}</Text>
          </View>
          <TouchableOpacity style={s.btnDanger} onPress={disconnect}>
            <Text style={s.btnDangerTxt}>قطع</Text>
          </TouchableOpacity>
        </View>
        <LogPanel log={log} />
      </View>
    );
  }

  return (
    <View style={s.container}>
      <Text style={s.title}>اتصال USB OTG</Text>
      <Text style={s.sub}>تأكد من توصيل كابل OTG وأن الرسيفر في وضع Download</Text>

      <View style={s.card}>
        <View style={s.cardHeader}>
          <Text style={s.cardTitle}>الأجهزة المتاحة</Text>
          <TouchableOpacity onPress={scanDevices} disabled={scanning} style={s.btnScan}>
            {scanning
              ? <ActivityIndicator size="small" color={COLORS.accent} />
              : <Text style={s.btnScanTxt}>بحث</Text>
            }
          </TouchableOpacity>
        </View>

        {devices.length === 0
          ? <Text style={s.empty}>لا توجد أجهزة — اضغط بحث أو تحقق من الكابل</Text>
          : <FlatList
              data={devices}
              keyExtractor={d => String(d.deviceId)}
              renderItem={({item}) => (
                <TouchableOpacity
                  style={s.deviceItem}
                  onPress={() => connect(item)}
                  disabled={connecting === item.deviceId}
                >
                  <View style={s.deviceIcon}>
                    <Text style={{fontSize: 20}}>🔌</Text>
                  </View>
                  <View style={{flex: 1}}>
                    <Text style={s.deviceName}>{item.name || 'USB Device'}</Text>
                    <Text style={s.deviceSub}>
                      VID: {item.vid?.toString(16).toUpperCase()}  PID: {item.pid?.toString(16).toUpperCase()}
                    </Text>
                  </View>
                  {connecting === item.deviceId
                    ? <ActivityIndicator size="small" color={COLORS.accent} />
                    : <Text style={s.connectBtn}>اتصال</Text>
                  }
                </TouchableOpacity>
              )}
            />
        }
      </View>

      <View style={s.card}>
        <Text style={s.cardTitle}>إرشادات الاتصال</Text>
        {[
          'وصّل كابل USB OTG بهاتفك',
          'وصّل الطرف الآخر بمنفذ USB الرسيفر',
          'أدخل الرسيفر في وضع Download Mode',
          'اضغط بحث ثم اتصال',
        ].map((step, i) => (
          <View key={i} style={s.step}>
            <View style={s.stepNum}><Text style={s.stepNumTxt}>{i + 1}</Text></View>
            <Text style={s.stepTxt}>{step}</Text>
          </View>
        ))}
      </View>

      <LogPanel log={log} />
    </View>
  );
}

function LogPanel({log}) {
  if (!log.length) return null;
  return (
    <View style={s.card}>
      <Text style={s.cardTitle}>سجل الاتصال</Text>
      {log.slice(0, 8).map((l, i) => (
        <Text key={i} style={s.logLine}>{l}</Text>
      ))}
    </View>
  );
}

const s = StyleSheet.create({
  container:     {flex: 1, backgroundColor: COLORS.bg, padding: 16},
  title:         {fontSize: 22, fontWeight: '700', color: COLORS.text, marginBottom: 4},
  sub:           {fontSize: 13, color: COLORS.muted, marginBottom: 20},
  card:          {backgroundColor: COLORS.bg2, borderRadius: 12, padding: 16, marginBottom: 14, borderWidth: 0.5, borderColor: COLORS.border},
  cardHeader:    {flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12},
  cardTitle:     {fontSize: 13, fontWeight: '600', color: COLORS.muted, textTransform: 'uppercase', letterSpacing: 0.5},
  empty:         {color: COLORS.muted, fontSize: 13, textAlign: 'center', paddingVertical: 16},
  deviceItem:    {flexDirection: 'row', alignItems: 'center', paddingVertical: 10, borderBottomWidth: 0.5, borderColor: COLORS.border},
  deviceIcon:    {width: 40, height: 40, borderRadius: 8, backgroundColor: COLORS.bg3, alignItems: 'center', justifyContent: 'center', marginRight: 12},
  deviceName:    {fontSize: 14, fontWeight: '600', color: COLORS.text},
  deviceSub:     {fontSize: 12, color: COLORS.muted, marginTop: 2, fontFamily: 'monospace'},
  connectBtn:    {color: COLORS.accent, fontSize: 13, fontWeight: '700'},
  btnScan:       {backgroundColor: COLORS.bg3, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 6},
  btnScanTxt:    {color: COLORS.accent, fontSize: 13, fontWeight: '600'},
  step:          {flexDirection: 'row', alignItems: 'center', marginBottom: 10},
  stepNum:       {width: 24, height: 24, borderRadius: 12, backgroundColor: COLORS.accent, alignItems: 'center', justifyContent: 'center', marginRight: 10},
  stepNumTxt:    {color: '#fff', fontSize: 12, fontWeight: '700'},
  stepTxt:       {fontSize: 13, color: COLORS.text, flex: 1},
  logLine:       {fontSize: 11, color: COLORS.muted, fontFamily: 'monospace', marginBottom: 3},
  connectedCard: {flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(34,197,94,0.1)', borderRadius: 12, padding: 16, marginBottom: 14, borderWidth: 1, borderColor: 'rgba(34,197,94,0.3)'},
  connDot:       {width: 10, height: 10, borderRadius: 5, backgroundColor: COLORS.green, marginRight: 12},
  connTitle:     {fontSize: 15, fontWeight: '700', color: COLORS.green},
  connSub:       {fontSize: 12, color: COLORS.muted, marginTop: 2, fontFamily: 'monospace'},
  btnDanger:     {backgroundColor: 'rgba(239,68,68,0.15)', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8, borderWidth: 1, borderColor: 'rgba(239,68,68,0.3)'},
  btnDangerTxt:  {color: COLORS.red, fontSize: 13, fontWeight: '600'},
});
