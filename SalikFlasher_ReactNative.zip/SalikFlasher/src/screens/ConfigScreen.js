// src/screens/ConfigScreen.js
import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet, Alert, ScrollView } from 'react-native';
import DocumentPicker from 'react-native-document-picker';
import RNFS from 'react-native-fs';
import { parseConfig, serializeConfig, validateSegments } from '../utils/ConfigParser';

const C = { bg:'#0f1117',bg2:'#1a1d27',bg3:'#22263a',border:'#2e3350',text:'#e2e8f0',muted:'#8892a4',accent:'#4f8ef7',green:'#22c55e',amber:'#f59e0b',red:'#ef4444' };
const SEG_COLORS = ['#4f8ef7','#7c3aed','#22c55e','#f59e0b','#ef4444','#14b8a6','#ec4899','#f97316'];

export default function ConfigScreen() {
  const [segments, setSegments] = useState([]);
  const [errors,   setErrors]   = useState([]);
  const [raw,      setRaw]      = useState('');

  async function loadConfig() {
    try {
      const res = await DocumentPicker.pickSingle({ type: DocumentPicker.types.allFiles });
      const text = await RNFS.readFile(res.fileCopyUri || res.uri, 'utf8');
      const segs = parseConfig(text);
      setSegments(segs);
      setRaw(text);
      setErrors(validateSegments(segs));
    } catch (e) { if (!DocumentPicker.isCancel(e)) Alert.alert('خطأ', e.message); }
  }

  function updateSeg(idx, field, val) {
    setSegments(prev => {
      const next = [...prev];
      next[idx] = { ...next[idx], [field]: val };
      if (field === 'startAddr') next[idx].startInt = parseInt(val, 16) || 0;
      if (field === 'size')      next[idx].sizeInt  = parseInt(val, 16) || 0;
      setErrors(validateSegments(next));
      return next;
    });
  }

  function addSeg() {
    setSegments(prev => [...prev, { index: prev.length, name: 'NewSeg', startAddr: '0x00200000', size: '0x00010000', startInt: 0x200000, sizeInt: 0x10000, endInt: 0x210000 }]);
  }
  function removeSeg(idx) { setSegments(prev => prev.filter((_, i) => i !== idx)); }

  async function saveConfig() {
    if (errors.length > 0) { Alert.alert('أخطاء', errors.join('\n')); return; }
    const text = serializeConfig(segments);
    const path = RNFS.DownloadDirectoryPath + '/config.ini';
    await RNFS.writeFile(path, text, 'utf8');
    Alert.alert('تم الحفظ', 'config.ini في مجلد التنزيلات:\n' + path);
  }

  const TOTAL = 8 * 1024 * 1024;
  return (
    <ScrollView style={s.container}>
      <TouchableOpacity style={s.loadBtn} onPress={loadConfig}>
        <Text style={s.loadBtnText}>📂 تحميل config.ini</Text>
      </TouchableOpacity>

      {segments.length > 0 && (
        <>
          <View style={s.mapContainer}>
            <View style={s.flashBar}>
              {segments.filter(sg => sg.name !== 'All').map((sg, i) => (
                <View key={i} style={[s.flashSeg, { flex: sg.sizeInt / TOTAL, backgroundColor: SEG_COLORS[i % SEG_COLORS.length] }]}>
                  {sg.sizeInt / TOTAL > 0.05 && <Text style={s.flashSegText}>{sg.name}</Text>}
                </View>
              ))}
            </View>
          </View>

          {errors.length > 0 && <View style={s.errBox}>{errors.map((e,i) => <Text key={i} style={s.errText}>⚠ {e}</Text>)}</View>}

          {segments.filter(sg => sg.name !== 'All').map((seg, i) => (
            <View key={i} style={s.segCard}>
              <View style={[s.segColor, { backgroundColor: SEG_COLORS[i % SEG_COLORS.length] }]} />
              <View style={{ flex: 1 }}>
                <TextInput style={s.segName} value={seg.name} onChangeText={v => updateSeg(i, 'name', v)} placeholderTextColor={C.muted} />
                <View style={s.segRow}>
                  <View style={{ flex: 1 }}>
                    <Text style={s.segLabel}>عنوان البداية</Text>
                    <TextInput style={s.segInput} value={seg.startAddr} onChangeText={v => updateSeg(i, 'startAddr', v)} placeholderTextColor={C.muted} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={s.segLabel}>الحجم</Text>
                    <TextInput style={s.segInput} value={seg.size} onChangeText={v => updateSeg(i, 'size', v)} placeholderTextColor={C.muted} />
                  </View>
                  <Text style={s.segKb}>{(seg.sizeInt/1024).toFixed(1)}K</Text>
                </View>
              </View>
              <TouchableOpacity onPress={() => removeSeg(i)} style={s.removeBtn}>
                <Text style={{ color: C.red }}>✕</Text>
              </TouchableOpacity>
            </View>
          ))}

          <View style={s.actRow}>
            <TouchableOpacity style={s.addBtn} onPress={addSeg}><Text style={{ color: C.muted }}>+ إضافة قسم</Text></TouchableOpacity>
            <TouchableOpacity style={s.saveBtn} onPress={saveConfig}><Text style={{ color:'#fff', fontWeight:'700' }}>💾 حفظ</Text></TouchableOpacity>
          </View>
        </>
      )}
    </ScrollView>
  );
}

const s = StyleSheet.create({
  container: { flex:1, backgroundColor:C.bg, padding:16 },
  loadBtn:   { backgroundColor:C.bg2, borderRadius:12, padding:14, alignItems:'center', marginBottom:12, borderWidth:1, borderColor:C.border },
  loadBtnText:{ color:C.text, fontWeight:'700' },
  mapContainer:{ marginBottom:12 },
  flashBar:  { height:36, flexDirection:'row', borderRadius:8, overflow:'hidden' },
  flashSeg:  { alignItems:'center', justifyContent:'center' },
  flashSegText:{ color:'#fff', fontSize:9, fontWeight:'700' },
  errBox:    { backgroundColor:'rgba(239,68,68,.1)', borderRadius:8, padding:10, marginBottom:10, borderWidth:1, borderColor:'rgba(239,68,68,.3)' },
  errText:   { color:C.red, fontSize:13 },
  segCard:   { flexDirection:'row', alignItems:'flex-start', gap:8, backgroundColor:C.bg2, borderRadius:10, padding:12, marginBottom:8, borderWidth:1, borderColor:C.border },
  segColor:  { width:4, borderRadius:2, alignSelf:'stretch', minHeight:60 },
  segName:   { color:C.text, fontWeight:'700', fontSize:14, marginBottom:8, padding:0 },
  segRow:    { flexDirection:'row', gap:8, alignItems:'center' },
  segLabel:  { color:C.muted, fontSize:10, marginBottom:3 },
  segInput:  { backgroundColor:C.bg3, color:C.accent, fontFamily:'monospace', fontSize:12, borderRadius:6, padding:7, borderWidth:1, borderColor:C.border },
  segKb:     { color:C.muted, fontSize:11, alignSelf:'flex-end', paddingBottom:6 },
  removeBtn: { padding:6 },
  actRow:    { flexDirection:'row', gap:10, marginTop:4, marginBottom:24 },
  addBtn:    { flex:1, backgroundColor:C.bg2, borderRadius:10, padding:12, alignItems:'center', borderWidth:1, borderColor:C.border },
  saveBtn:   { flex:1, backgroundColor:C.accent, borderRadius:10, padding:12, alignItems:'center' },
});
