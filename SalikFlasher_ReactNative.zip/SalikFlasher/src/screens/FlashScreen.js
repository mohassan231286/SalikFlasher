// src/screens/FlashScreen.js
import React, { useState, useRef } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert, ScrollView, ActivityIndicator } from 'react-native';
import DocumentPicker from 'react-native-document-picker';
import RNFS from 'react-native-fs';
import UsbSerial from '../utils/UsbSerial';

const C = { bg:'#0f1117',bg2:'#1a1d27',bg3:'#22263a',border:'#2e3350',text:'#e2e8f0',muted:'#8892a4',accent:'#4f8ef7',green:'#22c55e',amber:'#f59e0b',red:'#ef4444' };
const STEPS = ['اختيار الملف','مسح الذاكرة','كتابة الفيرموير','التحقق','اكتمال'];

export default function FlashScreen() {
  const [file,     setFile]     = useState(null);
  const [step,     setStep]     = useState(-1);
  const [progress, setProgress] = useState(0);
  const [chunks,   setChunks]   = useState({ done:0, total:0 });
  const [flashing, setFlashing] = useState(false);
  const [logs,     setLogs]     = useState([]);
  const [startAddr,setStartAddr]= useState('0x00010000');
  const scrollRef = useRef(null);

  function addLog(msg, type='info') {
    setLogs(prev => [...prev, { msg, type, id: Date.now() + Math.random() }]);
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated:true }), 80);
  }

  async function pickFile() {
    try {
      const res = await DocumentPicker.pickSingle({ type: DocumentPicker.types.allFiles, copyTo:'cachesDirectory' });
      const name = res.name || res.uri.split('/').pop();
      if (!name.match(/\.(bin|boot|img|abs)$/i)) { Alert.alert('خطأ','اختر ملف .bin أو .boot أو .img'); return; }
      setFile({ uri: res.fileCopyUri || res.uri, name, size: res.size });
      addLog('تم اختيار: ' + name + ' (' + (res.size/1024).toFixed(1) + ' KB)', 'success');
    } catch (e) { if (!DocumentPicker.isCancel(e)) addLog('فشل: ' + e.message, 'error'); }
  }

  async function startFlash() {
    if (!file) { Alert.alert('تنبيه','اختر ملف الفيرموير أولاً'); return; }
    if (!UsbSerial.isConnected()) { Alert.alert('تنبيه','اتصل بالرسيفر أولاً'); return; }
    Alert.alert('تأكيد الفلاش','سيتم مسح وكتابة الذاكرة. هذا لا يمكن التراجع عنه. هل أنت متأكد؟',
      [{ text:'إلغاء', style:'cancel' }, { text:'نعم، ابدأ', style:'destructive', onPress: doFlash }]);
  }

  async function doFlash() {
    setFlashing(true); setProgress(0); setLogs([]);
    try {
      const addr = parseInt(startAddr, 16);
      if (isNaN(addr)) throw new Error('عنوان البداية غير صالح');
      setStep(0); addLog('قراءة الملف...','info');
      const content  = await RNFS.readFile(file.uri, 'base64');
      const fileData = Buffer.from(content, 'base64');
      addLog('الحجم: ' + fileData.length.toLocaleString() + ' bytes','info');

      setStep(1); setProgress(5); addLog('مسح الذاكرة...','info');
      const erased = await UsbSerial.eraseFlash(addr, fileData.length, () => setProgress(p => Math.min(p+1,25)));
      if (!erased) throw new Error('فشل المسح');
      setProgress(25);

      setStep(2); addLog('كتابة الفيرموير...','info');
      const written = await UsbSerial.writeFlash(addr, fileData, (pct, done, total) => {
        setProgress(25 + Math.round(pct * 0.65));
        setChunks({ done, total });
      });
      if (!written) throw new Error('فشل الكتابة');
      setProgress(90);

      setStep(3); addLog('التحقق من الكتابة...','info');
      let crc = 0xFFFFFFFF;
      for (let i = 0; i < fileData.length; i++) { crc ^= fileData[i]; for (let j=0;j<8;j++) crc = (crc>>>1)^(crc&1?0xEDB88320:0); }
      crc = (crc ^ 0xFFFFFFFF) >>> 0;
      const verified = await UsbSerial.verifyFlash(addr, fileData.length, crc);
      setProgress(100); setStep(4);
      addLog(verified ? 'اكتمل الفلاش بنجاح ✓' : 'اكتمل مع تحذير في التحقق', verified ? 'success':'warn');
      if (verified) Alert.alert('نجاح ✓','تم الفلاش!\nهل تريد إعادة تشغيل الرسيفر؟',
        [{ text:'لاحقاً' }, { text:'إعادة تشغيل', onPress: () => UsbSerial.reboot() }]);
    } catch (e) {
      addLog('خطأ: ' + e.message,'error'); Alert.alert('فشلت العملية', e.message); setStep(-1);
    } finally { setFlashing(false); }
  }

  const lc = t => ({success:'#22c55e',error:'#ef4444',warn:'#f59e0b',info:'#8892a4'}[t]||'#8892a4');
  const lp = t => ({success:'✓',error:'✗',warn:'⚠',info:'›'}[t]||'›');

  return (
    <View style={s.container}>
      <View style={s.stepsRow}>
        {STEPS.map((label,i) => (
          <View key={i} style={s.stepItem}>
            <View style={[s.stepDot,{backgroundColor:step>i?C.green:step===i?C.accent:C.bg3,borderColor:step===i?C.accent:C.border}]}>
              <Text style={{color:'#fff',fontSize:11,fontWeight:'700'}}>{step>i?'✓':String(i+1)}</Text>
            </View>
            <Text style={[s.stepLabel,{color:step>=i?C.text:C.muted}]}>{label}</Text>
          </View>
        ))}
      </View>
      <View style={s.progressBar}><View style={[s.progressFill,{width:progress+'%',backgroundColor:step===4?C.green:C.accent}]}/></View>
      <Text style={s.progressTxt}>{progress}%</Text>
      <TouchableOpacity style={s.filePicker} onPress={pickFile} disabled={flashing}>
        {file ? <View><Text style={s.fileName}>📄 {file.name}</Text><Text style={s.fileSub}>{(file.size/1024).toFixed(1)} KB</Text></View>
              : <View style={{alignItems:'center'}}><Text style={{fontSize:32,marginBottom:8}}>📂</Text><Text style={{color:C.text,fontWeight:'600'}}>اختر ملف الفيرموير</Text><Text style={{color:C.muted,fontSize:12,marginTop:4}}>.bin .boot .img .abs</Text></View>}
      </TouchableOpacity>
      <View style={s.card}>
        <Text style={s.label}>عنوان البداية</Text>
        <View style={s.addrRow}>
          {['0x00000000','0x00010000','0x00130000'].map(addr => (
            <TouchableOpacity key={addr} style={[s.addrChip,startAddr===addr&&s.addrActive]} onPress={() => setStartAddr(addr)} disabled={flashing}>
              <Text style={[s.addrTxt,startAddr===addr&&{color:C.accent}]}>{addr}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
      <TouchableOpacity style={[s.flashBtn,flashing&&s.flashBtnOff]} onPress={startFlash} disabled={flashing}>
        {flashing ? <ActivityIndicator color="#fff"/> : <Text style={s.flashBtnTxt}>⚡ بدء الفلاش</Text>}
      </TouchableOpacity>
      <View style={[s.card,{flex:1}]}>
        <Text style={s.label}>السجل {chunks.total>0&&'— chunk '+chunks.done+'/'+chunks.total}</Text>
        <ScrollView ref={scrollRef} style={{flex:1}}>
          {logs.map(l => <Text key={l.id} style={[s.log,{color:lc(l.type)}]}>{lp(l.type)} {l.msg}</Text>)}
        </ScrollView>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  container:{flex:1,backgroundColor:C.bg,padding:16},
  stepsRow:{flexDirection:'row',justifyContent:'space-between',marginBottom:14},
  stepItem:{alignItems:'center',flex:1},
  stepDot:{width:26,height:26,borderRadius:13,borderWidth:1.5,alignItems:'center',justifyContent:'center',marginBottom:4},
  stepLabel:{fontSize:10,textAlign:'center'},
  progressBar:{height:8,backgroundColor:C.bg3,borderRadius:4,marginBottom:4,overflow:'hidden'},
  progressFill:{height:'100%',borderRadius:4},
  progressTxt:{color:C.muted,fontSize:12,textAlign:'right',marginBottom:12},
  filePicker:{borderWidth:2,borderStyle:'dashed',borderColor:C.border,borderRadius:12,padding:20,alignItems:'center',marginBottom:12,backgroundColor:C.bg2},
  fileName:{color:C.text,fontWeight:'700',fontSize:14},
  fileSub:{color:C.muted,fontSize:12,marginTop:2},
  card:{backgroundColor:C.bg2,borderRadius:12,padding:12,marginBottom:12,borderWidth:1,borderColor:C.border},
  label:{color:C.muted,fontSize:11,fontWeight:'700',textTransform:'uppercase',letterSpacing:0.8,marginBottom:8},
  addrRow:{flexDirection:'row',gap:8,flexWrap:'wrap'},
  addrChip:{backgroundColor:C.bg3,borderRadius:8,paddingHorizontal:10,paddingVertical:6,borderWidth:1,borderColor:C.border},
  addrActive:{borderColor:C.accent},
  addrTxt:{color:C.muted,fontFamily:'monospace',fontSize:12},
  flashBtn:{backgroundColor:C.accent,borderRadius:12,padding:16,alignItems:'center',marginBottom:12},
  flashBtnOff:{backgroundColor:C.border},
  flashBtnTxt:{color:'#fff',fontSize:16,fontWeight:'800'},
  log:{fontFamily:'monospace',fontSize:12,paddingVertical:1.5},
});
