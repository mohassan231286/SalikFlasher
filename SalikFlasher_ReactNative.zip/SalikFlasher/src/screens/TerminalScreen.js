// src/screens/TerminalScreen.js
import React, { useState, useRef, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';
import { UsbSerialport } from 'react-native-usb-serialport-for-android';
import UsbSerial from '../utils/UsbSerial';

const C = { bg:'#0f1117',bg2:'#1a1d27',bg3:'#22263a',border:'#2e3350',text:'#e2e8f0',muted:'#8892a4',accent:'#4f8ef7',green:'#22c55e',amber:'#f59e0b' };

const QUICK_CMDS = [
  { label:'Handshake', hex:'55' },
  { label:'Get Info',  hex:'55 AA 01 00 00 56' },
  { label:'Reboot',    hex:'55 AA 06 00 00 5B' },
];

export default function TerminalScreen() {
  const [lines,  setLines]  = useState([{ text:'طرفية Serial — GX6605S', type:'sys' }]);
  const [input,  setInput]  = useState('');
  const [hexMode,setHexMode]= useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    if (!UsbSerial.isConnected()) return;
    const sub = UsbSerialport.onReceived(data => {
      const bytes = Buffer.from(data, 'base64');
      const hex = Array.from(bytes).map(b => b.toString(16).padStart(2,'0').toUpperCase()).join(' ');
      const ascii = Array.from(bytes).map(b => b>=32&&b<127?String.fromCharCode(b):'.').join('');
      addLine('← ' + hex + '  |  ' + ascii, 'recv');
    });
    return () => sub.remove();
  }, []);

  function addLine(text, type='sys') {
    const ts = new Date().toLocaleTimeString('ar', { hour12:false });
    setLines(prev => [...prev, { text: '['+ts+'] '+text, type, id: Date.now()+Math.random() }]);
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated:true }), 80);
  }

  async function sendCmd() {
    if (!input.trim()) return;
    if (!UsbSerial.isConnected()) { addLine('غير متصل','err'); return; }
    try {
      let buf;
      if (hexMode) {
        const bytes = input.trim().split(/\s+/).map(h => parseInt(h,16));
        buf = Buffer.from(bytes);
      } else {
        buf = Buffer.from(input + '\r\n', 'utf8');
      }
      await UsbSerialport.write(buf.toString('base64'));
      const hex = Array.from(buf).map(b => b.toString(16).padStart(2,'0').toUpperCase()).join(' ');
      addLine('→ ' + hex, 'send');
      setInput('');
    } catch (e) { addLine('خطأ: ' + e.message, 'err'); }
  }

  function sendQuick(hex) {
    const bytes = hex.trim().split(/\s+/).map(h => parseInt(h,16));
    UsbSerialport.write(Buffer.from(bytes).toString('base64')).catch(() => {});
    addLine('→ ' + hex.toUpperCase(), 'send');
  }

  const lc = t => ({send:C.accent,recv:C.green,err:'#ef4444',sys:C.muted}[t]||C.muted);
  return (
    <View style={s.container}>
      <View style={s.quickRow}>
        {QUICK_CMDS.map((cmd,i) => (
          <TouchableOpacity key={i} style={s.qBtn} onPress={() => sendQuick(cmd.hex)}>
            <Text style={s.qBtnTxt}>{cmd.label}</Text>
          </TouchableOpacity>
        ))}
      </View>
      <ScrollView ref={scrollRef} style={s.terminal}>
        {lines.map((l,i) => <Text key={l.id||i} style={[s.line,{color:lc(l.type)}]}>{l.text}</Text>)}
      </ScrollView>
      <View style={s.inputRow}>
        <TouchableOpacity style={[s.modeBtn,hexMode&&s.modeBtnActive]} onPress={() => setHexMode(!hexMode)}>
          <Text style={{color:hexMode?C.accent:C.muted,fontSize:12}}>HEX</Text>
        </TouchableOpacity>
        <TextInput style={s.input} value={input} onChangeText={setInput} placeholder={hexMode?'55 AA 01...':'أدخل أمراً...'}
          placeholderTextColor={C.muted} onSubmitEditing={sendCmd} returnKeyType="send" autoCapitalize="none"/>
        <TouchableOpacity style={s.sendBtn} onPress={sendCmd}>
          <Text style={{color:'#fff',fontWeight:'700'}}>إرسال</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  container:{flex:1,backgroundColor:C.bg,padding:12},
  quickRow:{flexDirection:'row',gap:8,marginBottom:10,flexWrap:'wrap'},
  qBtn:{backgroundColor:C.bg2,borderRadius:8,paddingHorizontal:12,paddingVertical:7,borderWidth:1,borderColor:C.border},
  qBtnTxt:{color:C.muted,fontSize:12},
  terminal:{flex:1,backgroundColor:C.bg2,borderRadius:10,padding:10,marginBottom:10,borderWidth:1,borderColor:C.border},
  line:{fontFamily:'monospace',fontSize:12,paddingVertical:1},
  inputRow:{flexDirection:'row',gap:8,alignItems:'center'},
  modeBtn:{backgroundColor:C.bg2,borderRadius:8,paddingHorizontal:10,paddingVertical:10,borderWidth:1,borderColor:C.border},
  modeBtnActive:{borderColor:C.accent},
  input:{flex:1,backgroundColor:C.bg2,color:C.text,borderRadius:8,paddingHorizontal:12,paddingVertical:10,borderWidth:1,borderColor:C.border,fontFamily:'monospace'},
  sendBtn:{backgroundColor:C.accent,borderRadius:8,paddingHorizontal:16,paddingVertical:10},
});
