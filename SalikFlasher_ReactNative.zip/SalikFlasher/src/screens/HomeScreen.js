// src/screens/HomeScreen.js
import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, TouchableOpacity, FlatList,
  StyleSheet, ActivityIndicator, Alert,
} from 'react-native';
import UsbSerial from '../utils/UsbSerial';

const COLORS = {
  bg:      '#0f1117', bg2: '#1a1d27', bg3: '#22263a',
  border:  '#2e3350', text: '#e2e8f0', muted: '#8892a4',
  accent:  '#4f8ef7', green: '#22c55e', amber: '#f59e0b',
  red:     '#ef4444', teal: '#14b8a6',
};

export default function HomeScreen({ navigation }) {
  const [devices,    setDevices]    = useState([]);
  const [connected,  setConnected]  = useState(false);
  const [connecting, setConnecting] = useState(false);
  const [devInfo,    setDevInfo]    = useState(null);
  const [scanning,   setScanning]   = useState(false);
  const [logs,       setLogs]       = useState([]);

  // الاستماع لسجل الأحداث
  useEffect(() => {
    const unsub = UsbSerial.onLog(({ msg, type }) => {
      setLogs(prev => [{ msg, type, id: Date.now() }, ...prev].slice(0, 50));
    });
    return unsub;
  }, []);

  const scanDevices = useCallback(async () => {
    setScanning(true);
    const list = await UsbSerial.listDevices();
    setDevices(list);
    setScanning(false);
  }, []);

  useEffect(() => { scanDevices(); }, [scanDevices]);

  const handleConnect = async (device) => {
    setConnecting(true);
    const ok = await UsbSerial.connect(device.deviceId);
    if (ok) {
      setConnected(true);
      const info = await UsbSerial.getDeviceInfo();
      setDevInfo(info);
    } else {
      Alert.alert('فشل الاتصال', 'تأكد من:\n• وضع الرسيفر في وضع Flash\n• الكابل OTG متصل بشكل صحيح');
    }
    setConnecting(false);
  };

  const handleDisconnect = async () => {
    await UsbSerial.disconnect();
    setConnected(false);
    setDevInfo(null);
  };

  return (
    <View style={s.container}>
      {/* ── حالة الاتصال ── */}
      <View style={s.statusCard}>
        <View style={[s.statusDot, { backgroundColor: connected ? COLORS.green : COLORS.muted }]} />
        <View style={{ flex: 1 }}>
          <Text style={s.statusTitle}>{connected ? 'متصل بالرسيفر' : 'غير متصل'}</Text>
          {devInfo && (
            <Text style={s.statusSub}>
              GX6605S | Flash: {(devInfo.flashSize / 1024 / 1024).toFixed(0)}MB | v{devInfo.firmwareVer}
            </Text>
          )}
        </View>
        {connected && (
          <TouchableOpacity style={s.btnSmall} onPress={handleDisconnect}>
            <Text style={s.btnSmallText}>قطع</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* ── أجهزة USB ── */}
      {!connected && (
        <View style={s.card}>
          <View style={s.cardHeader}>
            <Text style={s.cardTitle}>أجهزة USB المتاحة</Text>
            <TouchableOpacity onPress={scanDevices} disabled={scanning}>
              {scanning
                ? <ActivityIndicator size="small" color={COLORS.accent} />
                : <Text style={s.link}>تحديث</Text>
              }
            </TouchableOpacity>
          </View>

          {devices.length === 0 ? (
            <View style={s.emptyBox}>
              <Text style={s.emptyIcon}>🔌</Text>
              <Text style={s.emptyText}>لا توجد أجهزة</Text>
              <Text style={s.emptySub}>وصّل كابل OTG ثم اضغط تحديث</Text>
            </View>
          ) : (
            <FlatList
              data={devices}
              keyExtractor={d => String(d.deviceId)}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={s.deviceItem}
                  onPress={() => handleConnect(item)}
                  disabled={connecting}
                >
                  <View style={s.deviceIcon}>
                    <Text style={{ fontSize: 20 }}>📡</Text>
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={s.deviceName}>{item.name || 'USB Device'}</Text>
                    <Text style={s.deviceSub}>
                      VID: {item.vendorId?.toString(16).toUpperCase()} |
                      PID: {item.productId?.toString(16).toUpperCase()}
                    </Text>
                  </View>
                  {connecting
                    ? <ActivityIndicator size="small" color={COLORS.accent} />
                    : <Text style={s.link}>اتصال</Text>
                  }
                </TouchableOpacity>
              )}
            />
          )}
        </View>
      )}

      {/* ── اختصارات سريعة ── */}
      {connected && (
        <View style={s.actionsRow}>
          <TouchableOpacity
            style={[s.actionBtn, { borderColor: COLORS.accent }]}
            onPress={() => navigation.navigate('Flash')}
          >
            <Text style={s.actionIcon}>⚡</Text>
            <Text style={[s.actionText, { color: COLORS.accent }]}>فلاش الفيرموير</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[s.actionBtn, { borderColor: COLORS.teal }]}
            onPress={() => navigation.navigate('Config')}
          >
            <Text style={s.actionIcon}>⚙️</Text>
            <Text style={[s.actionText, { color: COLORS.teal }]}>إعدادات Flash</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[s.actionBtn, { borderColor: COLORS.amber }]}
            onPress={() => navigation.navigate('Terminal')}
          >
            <Text style={s.actionIcon}>🖥️</Text>
            <Text style={[s.actionText, { color: COLORS.amber }]}>طرفية Serial</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* ── السجل ── */}
      <View style={[s.card, { flex: 1 }]}>
        <Text style={s.cardTitle}>سجل الأحداث</Text>
        <FlatList
          data={logs}
          keyExtractor={l => String(l.id)}
          renderItem={({ item }) => (
            <Text style={[s.logLine, { color: logColor(item.type) }]}>
              {logPrefix(item.type)} {item.msg}
            </Text>
          )}
          ListEmptyComponent={<Text style={s.emptySub}>لا توجد أحداث بعد</Text>}
        />
      </View>
    </View>
  );
}

function logColor(type) {
  return { success: COLORS.green, error: COLORS.red, warn: COLORS.amber, info: COLORS.muted }[type] || COLORS.muted;
}
function logPrefix(type) {
  return { success: '✓', error: '✗', warn: '⚠', info: '›' }[type] || '›';
}

const s = StyleSheet.create({
  container:   { flex: 1, backgroundColor: COLORS.bg, padding: 16 },
  statusCard:  { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: COLORS.bg2, borderRadius: 12, padding: 14, marginBottom: 12, borderWidth: 1, borderColor: COLORS.border },
  statusDot:   { width: 10, height: 10, borderRadius: 5 },
  statusTitle: { color: COLORS.text, fontWeight: '700', fontSize: 15 },
  statusSub:   { color: COLORS.muted, fontSize: 12, marginTop: 2, fontFamily: 'monospace' },
  card:        { backgroundColor: COLORS.bg2, borderRadius: 12, padding: 14, marginBottom: 12, borderWidth: 1, borderColor: COLORS.border },
  cardHeader:  { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  cardTitle:   { color: COLORS.muted, fontSize: 11, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.8 },
  link:        { color: COLORS.accent, fontSize: 13 },
  emptyBox:    { alignItems: 'center', padding: 24 },
  emptyIcon:   { fontSize: 32, marginBottom: 8 },
  emptyText:   { color: COLORS.text, fontSize: 15, fontWeight: '600' },
  emptySub:    { color: COLORS.muted, fontSize: 13, marginTop: 4 },
  deviceItem:  { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 10, backgroundColor: COLORS.bg3, borderRadius: 8, marginBottom: 6 },
  deviceIcon:  { width: 40, height: 40, borderRadius: 8, backgroundColor: COLORS.bg2, alignItems: 'center', justifyContent: 'center' },
  deviceName:  { color: COLORS.text, fontWeight: '600', fontSize: 14 },
  deviceSub:   { color: COLORS.muted, fontSize: 11, fontFamily: 'monospace', marginTop: 2 },
  actionsRow:  { flexDirection: 'row', gap: 10, marginBottom: 12 },
  actionBtn:   { flex: 1, alignItems: 'center', padding: 14, backgroundColor: COLORS.bg2, borderRadius: 12, borderWidth: 1 },
  actionIcon:  { fontSize: 24, marginBottom: 6 },
  actionText:  { fontSize: 12, fontWeight: '700' },
  btnSmall:    { backgroundColor: COLORS.bg3, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 6 },
  btnSmallText:{ color: COLORS.red, fontSize: 13 },
  logLine:     { fontFamily: 'monospace', fontSize: 12, paddingVertical: 2 },
});
